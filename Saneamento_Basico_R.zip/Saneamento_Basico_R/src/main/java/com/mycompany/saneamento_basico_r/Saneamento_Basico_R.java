/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.saneamento_basico_r;

/**
 *
 * @author renan
 */
public class Saneamento_Basico_R {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
